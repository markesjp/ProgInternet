package autoescola.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import autoescola.factory.ConnectionFactory;
import autoescola.model.Aula;
import autoescola.model.AulaDetalhada;

// Classe para gerenciar os dados das aulas no banco.
public class AulaDao {
    private ConnectionFactory factory;

    public AulaDao() {
        this.factory = new ConnectionFactory();
    }

    // Método auxiliar para mapear o ResultSet para um objeto Aula.
    private Aula mapearAula(ResultSet rs) throws SQLException {
        Aula aula = new Aula();
        aula.setId(rs.getInt("id"));
        aula.setAlunoId(rs.getInt("aluno_id"));
        aula.setInstrutorId(rs.getInt("instrutor_id"));
        
        // Verifica se 'veiculo_id' é NULL (ex: aulas teóricas)
        int veiculoId = rs.getInt("veiculo_id");
        if (rs.wasNull()) {
            aula.setVeiculoId(null);
        } else {
            aula.setVeiculoId(veiculoId);
        }
        
        // Converte java.sql.Timestamp para LocalDateTime
        aula.setDataAula(rs.getTimestamp("data_aula").toLocalDateTime());
        aula.setDuracaoMinutos(rs.getInt("duracao_minutos"));
        aula.setTipo(rs.getString("tipo"));
        aula.setStatus(rs.getString("status"));
        aula.setObservacoes(rs.getString("observacoes"));
        return aula;
    }

    // CREATE - Agenda uma nova aula.
    public void inserir(Aula aula) {
        // Observação: Veiculo_id pode ser NULL para aulas teóricas, por isso a checagem no código SQL
        String sql = "INSERT INTO aulas (aluno_id, instrutor_id, veiculo_id, data_aula, " +
                     "duracao_minutos, tipo, status, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, aula.getAlunoId());
            stmt.setInt(2, aula.getInstrutorId());
            
            // Lida com veiculo_id que pode ser null
            if (aula.getVeiculoId() != null) {
                stmt.setInt(3, aula.getVeiculoId());
            } else {
                stmt.setNull(3, java.sql.Types.INTEGER);
            }
            
            stmt.setTimestamp(4, Timestamp.valueOf(aula.getDataAula()));
            stmt.setInt(5, aula.getDuracaoMinutos());
            stmt.setString(6, aula.getTipo());
            stmt.setString(7, aula.getStatus());
            stmt.setString(8, aula.getObservacoes());

            stmt.execute();
            System.out.println("Aula inserida com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir aula: " + e.getMessage());
        }
    }

    // READ - Lista todas as aulas agendadas.
    public List<Aula> listar() {
        String sql = "SELECT * FROM aulas";
        List<Aula> aulas = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                aulas.add(mapearAula(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar aulas: " + e.getMessage());
        }

        return aulas;
    }

    /**
     * READ (melhorado) - Lista aulas com JOINs para exibir nomes e dados do veículo.
     * Ideal para a tela (interface) de visão/edição.
     */
    public List<AulaDetalhada> listarDetalhadas() {
        String sql = "SELECT a.id, a.aluno_id, al.nome AS aluno_nome, "
                + "a.instrutor_id, i.nome AS instrutor_nome, "
                + "a.veiculo_id, v.placa AS veiculo_placa, v.modelo AS veiculo_modelo, "
                + "a.data_aula, a.duracao_minutos, a.tipo, a.status, a.observacoes "
                + "FROM aulas a "
                + "INNER JOIN alunos al ON a.aluno_id = al.id "
                + "INNER JOIN instrutores i ON a.instrutor_id = i.id "
                + "LEFT JOIN veiculos v ON a.veiculo_id = v.id "
                + "ORDER BY a.data_aula DESC";

        List<AulaDetalhada> aulas = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                AulaDetalhada d = new AulaDetalhada();
                d.setId(rs.getInt("id"));

                d.setAlunoId(rs.getInt("aluno_id"));
                d.setAlunoNome(rs.getString("aluno_nome"));

                d.setInstrutorId(rs.getInt("instrutor_id"));
                d.setInstrutorNome(rs.getString("instrutor_nome"));

                int veiculoId = rs.getInt("veiculo_id");
                if (rs.wasNull()) {
                    d.setVeiculoId(null);
                } else {
                    d.setVeiculoId(veiculoId);
                }
                d.setVeiculoPlaca(rs.getString("veiculo_placa"));
                d.setVeiculoModelo(rs.getString("veiculo_modelo"));

                d.setDataAula(rs.getTimestamp("data_aula").toLocalDateTime());
                d.setDuracaoMinutos(rs.getInt("duracao_minutos"));
                d.setTipo(rs.getString("tipo"));
                d.setStatus(rs.getString("status"));
                d.setObservacoes(rs.getString("observacoes"));

                aulas.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar aulas detalhadas: " + e.getMessage());
        }

        return aulas;
    }

    // READ - Busca uma aula pelo ID.
    public Aula buscarPorId(Integer id) {
        String sql = "SELECT * FROM aulas WHERE id = ?";
        Aula aula = null;

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    aula = mapearAula(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar aula: " + e.getMessage());
        }

        return aula;
    }

    // UPDATE - Altera os dados de uma aula.
    public void alterar(Aula aula) {
        String sql = "UPDATE aulas SET aluno_id = ?, instrutor_id = ?, veiculo_id = ?, " +
                     "data_aula = ?, duracao_minutos = ?, tipo = ?, status = ?, " +
                     "observacoes = ? WHERE id = ?";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, aula.getAlunoId());
            stmt.setInt(2, aula.getInstrutorId());
            
            // Lida com veiculo_id que pode ser null
            if (aula.getVeiculoId() != null) {
                stmt.setInt(3, aula.getVeiculoId());
            } else {
                stmt.setNull(3, java.sql.Types.INTEGER);
            }
            
            stmt.setTimestamp(4, Timestamp.valueOf(aula.getDataAula()));
            stmt.setInt(5, aula.getDuracaoMinutos());
            stmt.setString(6, aula.getTipo());
            stmt.setString(7, aula.getStatus());
            stmt.setString(8, aula.getObservacoes());
            stmt.setInt(9, aula.getId());

            stmt.execute();
            System.out.println("Aula alterada com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao alterar aula: " + e.getMessage());
        }
    }

    // DELETE - Remove (cancela) uma aula.
    public void remover(Integer id) {
        String sql = "DELETE FROM aulas WHERE id = ?";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("Aula removida com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao remover aula: " + e.getMessage());
        }
    }

    // Método extra: Lista todas as aulas de um aluno específico.
    // CORRIGIDO: Adicionando o loop para popular a lista usando o método auxiliar.
    public List<Aula> listarPorAluno(Integer alunoId) {
        String sql = "SELECT * FROM aulas WHERE aluno_id = ? ORDER BY data_aula DESC";
        List<Aula> aulas = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, alunoId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    aulas.add(mapearAula(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar aulas por aluno: " + e.getMessage());
        }

        return aulas;
    }

    // Método extra: Lista todas as aulas de um instrutor.
    // CORRIGIDO: Adicionando o loop para popular a lista usando o método auxiliar.
    public List<Aula> listarPorInstrutor(Integer instrutorId) {
        String sql = "SELECT * FROM aulas WHERE instrutor_id = ? ORDER BY data_aula DESC";
        List<Aula> aulas = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, instrutorId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    aulas.add(mapearAula(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar aulas por instrutor: " + e.getMessage());
        }

        return aulas;
    }

    // Método extra: Busca aulas com JOIN para mostrar informações mais completas.
    // Este método já estava correto e completo.
    public List<String> listarAulasCompletas() {
        // Uso de LEFT JOIN em vez de INNER JOIN para incluir aulas teóricas (veiculo_id NULL)
        String sql = "SELECT a.id, al.nome AS aluno_nome, i.nome AS instrutor_nome, " +
                     "v.placa, v.modelo, a.data_aula, a.tipo, a.status " +
                     "FROM aulas a " +
                     "INNER JOIN alunos al ON a.aluno_id = al.id " +
                     "INNER JOIN instrutores i ON a.instrutor_id = i.id " +
                     "LEFT JOIN veiculos v ON a.veiculo_id = v.id " + // LEFT JOIN: Veículo é opcional
                     "ORDER BY a.data_aula DESC";

        List<String> aulasDetalhadas = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                // Checa se o veículo é nulo (para aulas teóricas)
                String veiculoInfo = (rs.getString("modelo") != null) 
                                     ? String.format("%s (%s)", rs.getString("modelo"), rs.getString("placa"))
                                     : "N/A (Teórica)";
                
                String detalhes = String.format(
                    "Aula #%d | Aluno: %s | Instrutor: %s | Veículo: %s | Data: %s | Tipo: %s | Status: %s",
                    rs.getInt("id"),
                    rs.getString("aluno_nome"),
                    rs.getString("instrutor_nome"),
                    veiculoInfo, // Usando a info formatada
                    rs.getTimestamp("data_aula"),
                    rs.getString("tipo"),
                    rs.getString("status")
                );
                aulasDetalhadas.add(detalhes);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar aulas completas: " + e.getMessage());
        }

        return aulasDetalhadas;
    }
}
package autoescola.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import autoescola.factory.ConnectionFactory;
import autoescola.model.Aluno;

// Essa classe faz a comunicação com a tabela de 'alunos' no banco.
public class AlunoDao {
    private ConnectionFactory factory;

    public AlunoDao() {
        this.factory = new ConnectionFactory();
    }

    // NOVO MÉTODO: Verifica se um CPF já existe no banco.
    public boolean existeCpf(String cpf) {
        String sql = "SELECT COUNT(id) FROM alunos WHERE cpf = ?";
        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Se o COUNT for maior que 0, significa que o CPF já existe.
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao verificar existência de CPF do aluno: " + e.getMessage());
        }
        return false;
    }

    // CREATE - Insere um novo aluno no banco.
    public void inserir(Aluno aluno) {
        String sql = "INSERT INTO alunos (nome, cpf, telefone, email, data_nascimento, " +
                     "categoria_desejada, data_matricula) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setString(3, aluno.getTelefone());
            stmt.setString(4, aluno.getEmail());
            // Converte LocalDate para java.sql.Date
            stmt.setDate(5, Date.valueOf(aluno.getDataNascimento()));
            stmt.setString(6, aluno.getCategoriaDesejada());
            // Converte LocalDate para java.sql.Date
            stmt.setDate(7, Date.valueOf(aluno.getDataMatricula()));

            stmt.execute();
            // REMOVIDO: System.out.println("Aluno inserido com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir aluno: " + e.getMessage());
        }
    }

    // Método auxiliar para mapear o ResultSet para um objeto Aluno
    private Aluno mapearAluno(ResultSet rs) throws SQLException {
        Aluno aluno = new Aluno();
        aluno.setId(rs.getInt("id"));
        aluno.setNome(rs.getString("nome"));
        aluno.setCpf(rs.getString("cpf"));
        aluno.setTelefone(rs.getString("telefone"));
        aluno.setEmail(rs.getString("email"));
        // Converte java.sql.Date para LocalDate
        aluno.setDataNascimento(rs.getDate("data_nascimento").toLocalDate());
        aluno.setCategoriaDesejada(rs.getString("categoria_desejada"));
        // Converte java.sql.Date para LocalDate
        aluno.setDataMatricula(rs.getDate("data_matricula").toLocalDate());
        return aluno;
    }

    // READ - Lista todos os alunos cadastrados.
    public List<Aluno> listar() {
        String sql = "SELECT * FROM alunos";
        List<Aluno> alunos = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                // Usando método auxiliar para preencher o objeto
                alunos.add(mapearAluno(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar alunos: " + e.getMessage());
        }

        return alunos;
    }

    // READ - Busca um aluno específico pelo ID.
    public Aluno buscarPorId(Integer id) {
        String sql = "SELECT * FROM alunos WHERE id = ?";
        Aluno aluno = null;

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Usando método auxiliar para preencher o objeto
                    aluno = mapearAluno(rs);
                }
            } // ResultSet fechado automaticamente
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar aluno: " + e.getMessage());
        }

        return aluno;
    }

    // UPDATE - Altera os dados de um aluno.
    public void alterar(Aluno aluno) {
        String sql = "UPDATE alunos SET nome = ?, cpf = ?, telefone = ?, email = ?, " +
                     "data_nascimento = ?, categoria_desejada = ?, data_matricula = ? WHERE id = ?";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setString(3, aluno.getTelefone());
            stmt.setString(4, aluno.getEmail());
            stmt.setDate(5, Date.valueOf(aluno.getDataNascimento()));
            stmt.setString(6, aluno.getCategoriaDesejada());
            stmt.setDate(7, Date.valueOf(aluno.getDataMatricula()));
            stmt.setInt(8, aluno.getId());

            stmt.execute();
            System.out.println("Aluno alterado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao alterar aluno: " + e.getMessage());
        }
    }

    // DELETE - Remove um aluno do banco.
    public void remover(Integer id) {
        String sql = "DELETE FROM alunos WHERE id = ?";

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.execute();
            System.out.println("Aluno removido com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao remover aluno: " + e.getMessage());
        }
    }

    // Método extra: Busca todos os alunos que querem uma categoria específica.
    public List<Aluno> buscarPorCategoria(String categoria) {
        String sql = "SELECT * FROM alunos WHERE categoria_desejada = ?";
        List<Aluno> alunos = new ArrayList<>();

        try (Connection conn = factory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, categoria);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    // Usando método auxiliar para preencher o objeto
                    alunos.add(mapearAluno(rs));
                }
            } // ResultSet fechado automaticamente
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar alunos por categoria: " + e.getMessage());
        }

        return alunos;
    }
}
package autoescola.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import autoescola.dao.AlunoDao;
import autoescola.model.Aluno;

/**
 * AlunoServlet
 *
 * Melhorias:
 * - Suporte a API JSON (para interface moderna com tabela, edição e exclusão).
 * - Validações de entrada + mensagens de erro com HTTP status.
 * - Implementa métodos do ciclo de vida: init(), service(), destroy().
 *
 * Rotas:
 * - GET  /alunos                -> redireciona para alunos.html
 * - GET  /alunos?format=json    -> lista
 * - GET  /alunos?op=get&id=1&format=json -> detalhe
 * - POST /alunos (op=create|update|delete) -> CRUD via JSON
 */
@WebServlet("/alunos")
public class AlunoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AlunoDao dao;

    // --------------------------
    // Ciclo de vida
    // --------------------------
    @Override
    public void init() throws ServletException {
        super.init();
        this.dao = new AlunoDao();
        getServletContext().log("[AlunoServlet] init() - inicializado");
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        long start = System.currentTimeMillis();
        try {
            super.service(req, resp);
        } finally {
            long ms = System.currentTimeMillis() - start;
            getServletContext().log("[AlunoServlet] service() - " + req.getMethod() + " " + req.getRequestURI() + " (" + ms + "ms)");
        }
    }

    @Override
    public void destroy() {
        getServletContext().log("[AlunoServlet] destroy() - finalizando");
        this.dao = null;
        super.destroy();
    }

    // --------------------------
    // GET
    // --------------------------
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!isJsonRequest(request)) {
            response.sendRedirect("alunos.html");
            return;
        }

        String op = nvl(request.getParameter("op"), "list");

        try {
            if ("list".equalsIgnoreCase(op)) {
                List<Aluno> alunos = dao.listar();
                writeJson(response, 200, alunosToJson(alunos));
                return;
            }

            if ("get".equalsIgnoreCase(op)) {
                Integer id = parseInt(request.getParameter("id"));
                if (id == null || id <= 0) {
                    writeJson(response, 400, errJson("Parâmetro 'id' inválido."));
                    return;
                }
                Aluno a = dao.buscarPorId(id);
                if (a == null) {
                    writeJson(response, 404, errJson("Aluno não encontrado."));
                    return;
                }
                writeJson(response, 200, alunoToJson(a));
                return;
            }

            writeJson(response, 400, errJson("Operação inválida: op=" + op));
        } catch (RuntimeException e) {
            writeJson(response, 500, errJson("Falha ao consultar alunos: " + safeMsg(e)));
        }
    }

    // --------------------------
    // POST
    // --------------------------
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        boolean json = isJsonRequest(request);

        // Compatibilidade: HTML antigo usa name="acao".
        String op = request.getParameter("op");
        if (op == null || op.trim().isEmpty()) {
            String acao = request.getParameter("acao");
            if ("cadastrar".equalsIgnoreCase(acao)) op = "create";
            else if ("alterar".equalsIgnoreCase(acao)) op = "update";
            else if ("remover".equalsIgnoreCase(acao)) op = "delete";
        }
        op = nvl(op, "").toLowerCase();

        try {
            if ("create".equals(op)) {
                Aluno aluno = readAlunoFromRequest(request, false);
                validateAluno(aluno, false);

                if (dao.existeCpf(aluno.getCpf())) {
                    respond(response, json, 409, errJson("CPF já cadastrado."), "alunos.html?erro=CPF+já+cadastrado");
                    return;
                }

                dao.inserir(aluno);
                respond(response, json, 200, okJson("Aluno cadastrado com sucesso."), "alunos.html?msg=Aluno+cadastrado+com+sucesso");
                return;
            }

            if ("update".equals(op)) {
                Aluno aluno = readAlunoFromRequest(request, true);
                validateAluno(aluno, true);

                Aluno existente = dao.buscarPorId(aluno.getId());
                if (existente == null) {
                    respond(response, json, 404, errJson("Aluno não encontrado."), "alunos.html?erro=Aluno+não+encontrado");
                    return;
                }

                // Se trocar CPF, precisa checar duplicidade
                if (!safeEquals(existente.getCpf(), aluno.getCpf()) && dao.existeCpf(aluno.getCpf())) {
                    respond(response, json, 409, errJson("CPF já cadastrado."), "alunos.html?erro=CPF+já+cadastrado");
                    return;
                }

                dao.alterar(aluno);
                respond(response, json, 200, okJson("Aluno atualizado com sucesso."), "alunos.html?msg=Aluno+atualizado+com+sucesso");
                return;
            }

            if ("delete".equals(op)) {
                Integer id = parseInt(nvl(request.getParameter("id"), request.getParameter("id_remover")));
                if (id == null || id <= 0) {
                    respond(response, json, 400, errJson("ID inválido."), "alunos.html?erro=ID+inválido");
                    return;
                }
                Aluno existente = dao.buscarPorId(id);
                if (existente == null) {
                    respond(response, json, 404, errJson("Aluno não encontrado."), "alunos.html?erro=Aluno+não+encontrado");
                    return;
                }
                dao.remover(id);
                respond(response, json, 200, okJson("Aluno removido com sucesso."), "alunos.html?msg=Aluno+removido+com+sucesso");
                return;
            }

            respond(response, json, 400, errJson("Operação inválida."), "alunos.html?erro=Operação+inválida");
        } catch (IllegalArgumentException e) {
            respond(response, json, 400, errJson(safeMsg(e)), "alunos.html?erro=" + urlEncode(safeMsg(e)));
        } catch (RuntimeException e) {
            respond(response, json, 500, errJson("Falha ao processar: " + safeMsg(e)), "alunos.html?erro=Falha+ao+processar");
        }
    }

    // --------------------------
    // Leitura/Validação
    // --------------------------
    private Aluno readAlunoFromRequest(HttpServletRequest request, boolean requireId) {
        Aluno aluno = new Aluno();

        if (requireId) {
            Integer id = parseInt(request.getParameter("id"));
            if (id == null || id <= 0) {
                throw new IllegalArgumentException("Informe um ID válido para editar.");
            }
            aluno.setId(id);
        }

        aluno.setNome(trim(request.getParameter("nome")));
        aluno.setCpf(trim(request.getParameter("cpf")));
        aluno.setTelefone(trim(request.getParameter("telefone")));
        aluno.setEmail(trim(request.getParameter("email")));
        aluno.setCategoriaDesejada(trim(request.getParameter("categoria_desejada")));

        String dn = trim(request.getParameter("data_nascimento"));
        if (!dn.isEmpty()) {
            aluno.setDataNascimento(LocalDate.parse(dn));
        }

        String dm = trim(request.getParameter("data_matricula"));
        if (!dm.isEmpty()) {
            aluno.setDataMatricula(LocalDate.parse(dm));
        }

        return aluno;
    }

    private void validateAluno(Aluno aluno, boolean requireId) {
        if (requireId && (aluno.getId() == null || aluno.getId() <= 0)) {
            throw new IllegalArgumentException("ID inválido.");
        }
        if (isBlank(aluno.getNome()) || aluno.getNome().length() < 2) {
            throw new IllegalArgumentException("Nome é obrigatório (mín. 2 caracteres).");
        }
        if (isBlank(aluno.getCpf())) {
            throw new IllegalArgumentException("CPF é obrigatório.");
        }
        if (aluno.getDataNascimento() == null) {
            throw new IllegalArgumentException("Data de nascimento é obrigatória.");
        }
        if (isBlank(aluno.getCategoriaDesejada())) {
            throw new IllegalArgumentException("Categoria desejada é obrigatória.");
        }
        if (aluno.getDataMatricula() == null) {
            throw new IllegalArgumentException("Data de matrícula é obrigatória.");
        }
    }

    // --------------------------
    // JSON helpers
    // --------------------------
    private String alunosToJson(List<Aluno> alunos) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < alunos.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(alunoToJson(alunos.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    private String alunoToJson(Aluno a) {
        return "{" +
                "\"id\":" + a.getId() + "," +
                "\"nome\":\"" + j(a.getNome()) + "\"," +
                "\"cpf\":\"" + j(a.getCpf()) + "\"," +
                "\"telefone\":\"" + j(nvl(a.getTelefone(), "")) + "\"," +
                "\"email\":\"" + j(nvl(a.getEmail(), "")) + "\"," +
                "\"data_nascimento\":\"" + j(a.getDataNascimento() != null ? a.getDataNascimento().toString() : "") + "\"," +
                "\"categoria_desejada\":\"" + j(a.getCategoriaDesejada()) + "\"," +
                "\"data_matricula\":\"" + j(a.getDataMatricula() != null ? a.getDataMatricula().toString() : "") + "\"" +
                "}";
    }

    private String okJson(String msg) {
        return "{\"ok\":true,\"message\":\"" + j(msg) + "\"}";
    }

    private String errJson(String msg) {
        return "{\"ok\":false,\"message\":\"" + j(msg) + "\"}";
    }

    private void writeJson(HttpServletResponse resp, int status, String json) throws IOException {
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");
        resp.getWriter().write(json);
    }

    private void respond(HttpServletResponse resp, boolean json, int status, String jsonBody, String redirectUrl) throws IOException {
        if (json) {
            writeJson(resp, status, jsonBody);
        } else {
            // fallback (HTML tradicional)
            resp.sendRedirect(redirectUrl);
        }
    }

    private boolean isJsonRequest(HttpServletRequest req) {
        String format = req.getParameter("format");
        if (format != null && format.equalsIgnoreCase("json")) return true;
        String accept = req.getHeader("Accept");
        return accept != null && accept.toLowerCase().contains("application/json");
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static Integer parseInt(String s) {
        try {
            if (s == null || s.trim().isEmpty()) return null;
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

    private static String nvl(String s, String def) {
        return (s == null || s.trim().isEmpty()) ? def : s.trim();
    }

    private static String j(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static boolean safeEquals(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.equals(b);
    }

    private static String safeMsg(Exception e) {
        String m = e.getMessage();
        return m == null ? "Erro inesperado" : m;
    }

    private static String urlEncode(String s) {
        try {
            return java.net.URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
